#coding=utf-8

import cv2
import numpy as np
import time
import sys
import torch

from PIL import Image
from face_detection import *
from torch.autograd import Variable

from PyQt5 import QtWidgets, QtGui, QtCore
from PyQt5.QtCore import QObject, pyqtSignal, QThread, QMutex, QMutexLocker
from PyQt5.QtGui import QImage, QPixmap
from PyQt5.QtWidgets import (QApplication, QDialog, QFileDialog, QGridLayout,
                             QLabel, QPushButton, QFrame, QComboBox)

class Camera:
    def __init__(self, width=320, height=320):
        self.cap = cv2.VideoCapture(0)
        self.image= QImage()
        self.width = width
        self.height = height
        ret, frame = self.cap.read()
        frame = cv2.resize(frame, (self.width, self.height))
        self.h, self.w, self.bytesPerComponent = frame.shape
        self.bytesPerLine = self.bytesPerComponent * self.w
    def Returnoneframe(self):
        # get a frame
        ret, frame = self.cap.read()
        frame = cv2.resize(frame, (self.width, self.height))
        return frame
    def ReturnOneQPixmap(self):
        # get a frame
        ret, frame = self.cap.read()
        frame = cv2.resize(frame, (self.width, self.height))
        if ret:
            if frame.ndim == 3:
                rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

            elif frame.ndim == 2:
                rgb = cv2.cvtColor(frame, cv2.COLOR_GRAY2BGR)

        self.image = QImage(rgb.data, self.w, self.h, self.bytesPerLine, QImage.Format_RGB888)
        return QPixmap.fromImage(self.image)

    def DestroyCamera(self):
        self.cap.release()
        cv2.destroyAllWindows()



class VideoBox(QDialog):

    def __init__(self):
        QDialog.__init__(self)
        self.img = np.ndarray(())
        self.setWindowTitle("image-process")
        self.resize(1350, 750)
        #self.setWindowFlags(Qt.CustomizeWindowHint)
        self.camera = Camera(600, 600)
        self.Label = QLabel()

        self.Label.setFixedSize(600, 600)
        self.Label.setObjectName("Camera")
        self.Label.setText("视频流")
        self.label2 = QLabel()
        self.label2.setFixedSize(600,600)
        self.label2.setText("处理结果")
        self.btnQuit = QPushButton('退出', self)
        #self.btnProcess = QPushButton('图像处理', self)
        self.combo = QComboBox()
        self.combo.addItem('Start')
        self.combo.addItem('Stop')
        layout = QGridLayout(self)
        layout.addWidget(self.Label, 0, 0, 4, 4)
        layout.addWidget(self.label2, 0, 5, 4, 4)
        layout.addWidget(self.combo, 4, 0, 1, 1)
        #layout.addWidget(self.btnProcess, 4, 1, 1, 1)
        layout.addWidget(self.btnQuit, 4, 1, 1, 1)
        self.combo.activated[str].connect(self.onActivatd)
        #self.btnProcess.clicked.connect(self.processSlot)
        self.btnQuit.clicked.connect(self.close)
        self.video_timer = VideoTimer()
        self.video_timer.timeSignal.signal[str].connect(self.showframe)
    def onActivatd(self, text):
        if text == 'Start':
            self.video_timer.start()
            #print('Video')

        if text == 'Stop':
            self.video_timer.stop()
            #quit()
    def close(self):
        quit()
    def showframe(self):
        self.Label.setPixmap(self.camera.ReturnOneQPixmap())
        self.img = self.camera.Returnoneframe()
        #self.img = cv2.blur(self.img, (5, 5))

        conf_thres=0.8
        nms_thres=0.4
        img_size=416
        # 转化为Tensor float类型
        model,classes=load_model()
        Tensor = torch.cuda.FloatTensor if torch.cuda.is_available() else torch.FloatTensor
        colors = np.random.randint(0,255,size=(len(classes),3),dtype="uint8")
        img_detections = []
        # 开始检测
        start = time.time()
        current_frame = 0
        # 将将numpy的矩阵转化成PIL 再将opencv中获取的BGR颜色空间转换成RGB
        PILimg = np.array(Image.fromarray(cv2.cvtColor(self.img, cv2.COLOR_BGR2RGB)))
        imgTensor = transforms.ToTensor()(PILimg)
        imgTensor, _ = pad_to_square(imgTensor, 0)
        # resize图像变成416×416
        imgTensor = resize(imgTensor, 416)
        # 添加一个维度
        imgTensor = imgTensor.unsqueeze(0)
        imgTensor = Variable(imgTensor.type(Tensor))

        # 检测
        with torch.no_grad():
            detections = model(imgTensor)
            detections = non_max_suppression(detections, conf_thres, nms_thres)
        current_frame += 1
        img_detections.clear()
        if detections is not None:
            img_detections.extend(detections)
        length = len(img_detections)
        if length:
            for detections in img_detections:
                if detections is not None:
                    detections = rescale_boxes(detections, img_size, PILimg.shape[:2])
                    unique_labels = detections[:, -1].cpu().unique()
                    n_cls_preds = len(unique_labels)
                    end = time.time()
                    time_count = end - start
                    for x1, y1, x2, y2, conf, cls_conf, cls_pred in detections:
                        box_w = x2 - x1
                        box_h = y2 - y1
                        color = [int(clr) for clr in colors[int(cls_pred)]]
                        self.img = cv2.rectangle(self.img, (x1, y1 + box_h), (x2, x1), color, 2)
                        cv2.putText(self.img, classes[int(cls_pred)], (x1, y1), cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 2)
                        cv2.putText(self.img, str("%.2f" % float(conf)), (x2, y2 - box_h), cv2.FONT_HERSHEY_SIMPLEX, 0.5,
                                   color, 2)

        height, width, channel = self.img.shape
        bytesPerLine = 3 * width
        self.qImg = QImage(self.img.data, width, height, bytesPerLine, QImage.Format_RGB888).rgbSwapped()
        # 适应label
        jpg = QtGui.QPixmap(self.qImg).scaled(self.label2.width(), self.label2.height())
        self.label2.setPixmap(jpg)

class Communicate(QObject):
    signal = pyqtSignal(str)
class VideoTimer(QThread):
    def __init__(self, frequent=15):
        QThread.__init__(self)
        self.stopped = False
        self.frequent = frequent
        self.timeSignal = Communicate()
        self.mutex = QMutex()

    def run(self):
        with QMutexLocker(self.mutex):
            self.stopped = False

        while True:
            if self.stopped:
                return
            self.timeSignal.signal.emit("1")
            time.sleep(1 / self.frequent)

    def stop(self):
        with QMutexLocker(self.mutex):
            self.stopped = True

    def is_stopped(self):
        with QMutexLocker(self.mutex):
            return self.stopped

    def set_fps(self, fps):
        self.frequent = fps

if __name__ == "__main__":
    app = QApplication(sys.argv)
    box = VideoBox()
    box.show()
    sys.exit(app.exec_())
